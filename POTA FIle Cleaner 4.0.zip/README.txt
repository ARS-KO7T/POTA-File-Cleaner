POTA FILE CLEANER 4.0

The POTA File Cleaner takes an adi file exported from logging software and removes all superflous aid fields from each QSO record in the log while preserving the minimun adi fields necessary for POTA activator log uploads and organizes the fields for easy review if there are any issues uploading the activator log to the POTA App site. This updated version will also automatically generate an adi file for multi-park (n-fer) activations by listing all park numbers separated by a comma-separated (e.g. US-1234, US-23456,US-5669). The output adi file(s) also include the new adi fields of MY_POTA_REF, and POTA_REF for each QSO record in the log.

This program removes all fields and data from the original adi file from your logging software except:
 - Call
 - Time_On
 - Date
 - Band
 - Mode
 - Sig_Info (if P2P contact)

and adds the following fields and data supplied by you to the output adi files to upload to POTA App.
 - Station_Callsign
 - Operator callsign (optional)
 - My_State (for US parks)
 - My_Pota_Ref (all parks entered correctly in the Park Reference(s) textbox
 - Pota_Ref (if Sig_Info field has a park reference)

(Note: The My_Pota_Ref and Pota_Ref fields are fields that were added to the ADIF specification but have not yet been implemented in the POTA Ap backend.)

USAGE:
------------------------------
Select the adi file exported from your logging software
Enter the park reference (or multiple park numbers separated by a comma if you activated an n-fer.
If it is a US or Canadian Park the State or Province dropdown list will appear and select the appropriate state or province.
Enter the Station callsign used for the activation
If it is a club activation click the checkbox and enter the operator's callsign
If you used a self-assigned indicator or dx prefix you can also check this box and enter your primary callsign
If you want to review the output select either ADIF Master (if installed) or Notepad

Once the files are generated and saved to the selected folder (the Desktop is the default folder), you can select to view the last output file in ADIF Master (if it is installed), or Windows Notepad. 


Version 4 has several refactored methods to improve performance and some minor bug fixes. This program also has some rudimentary error checking for proper park reference formats, station and operator callsign formats.

